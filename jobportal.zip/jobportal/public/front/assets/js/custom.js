$(document).ready(function(){
   
    $(document).on('click',".subservice",function(){
        var service = $(this).attr('data2');
        var subservice = $(this).attr('data');

        $.ajax({
            url:'/servicewise/subservice/worker/'+service+'/'+subservice,
            method:"get",
            success:function(res){
                if (res.length>0) {
                    for (let i = 0; i < res.length; i++) {
                   
                        $('#listworker').html('');
                        $('#listworker').html('<div class="listCandidates" style="margin: 30px;border-bottom: 1px solid #efefef;"> <div class="row"> <div class="col-sm-8"> <div class="media d-flex"> <div class="jobImage w-auto"> <div class="image-card"> <img src="/images/'+res[i].image+'" alt="Candidate-1" style="max-width: 132px;max-height: 132px;"/> </div> </div> <div class="media-body"> <h5>'+res[i].name +experienceFunc(res[i].experience)+'<small>'+reviewFunc(res[i].review)+' review</small></h5> <ul class="list-inline"> <li class="list-inline-item"> <i class="fa fa-phone mr-2" aria-hidden="true"></i> <span class="f_rubik">'+res[i].phone+'</span> </li> <li class="list-inline-item"> <i class="fa fa-map-marker mr-2" aria-hidden="true"></i>'+res[i].location+'</li> <li class="list-inline-item"> <i class="fa fa-venus-mars mr-2" aria-hidden="true"></i>'+res[i].gender+'</li> </ul> <ul class="list-inline editText mb-0">'+myfunc(res[i].subservice)+'</ul> </div> </div> </div> <div class="col-sm-4 text-center listRight"> <h5 class="f_rubik"> $ '+res[i].rate+'<span>(/Hour)</span></h5> <a href="/details/'+res[i].name+'" class="btn btn-outline-dark rounded-pill float-left"> View Details </a><a href="/details/"'+res[i].name+' style="padding: 6px 20px;font-size: 16.62px;margin-top: 20px;border: 1px solid #000;border-radius: 50rem!important; float: left;text-decoration: none;">Hire Now</a> </div> </div> </div>');
                    }
                } else {
                    alert('No Details Found')
                }
                
            },
            error:function(err){
                alert(error)
            }

        })
    })

    function myfunc(sub){
        var x = '';
        for (let index = 0; index < sub.length; index++) {
            x = x+'<li class="list-inline-item text-white bg-dark font-weight-light p-1" >'+sub[index]+'</li>'            
        }

        return x;
    }

    function experienceFunc(exp){
        var x = '';
        if (exp!='') {
            x = '<span class="ml-2 mr-2 text-success " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Experienced"><i class="fa fa-certificate border-0 text-success" aria-hidden="true"></i></span>'
        }

        return x;
    }
    
    function reviewFunc(rvw){

        if (rvw!=null) {
            return rvw.length;
        }else{
            return 0;
        }
    }
    

    // checkout total amount count
    $(document).on('change','#hrnumber',function(){
        var rate = $('#totalamount').attr('data');
        var hr = $(this).val();

        var total = rate*hr;
        $('#totalamount').text(total)

    })
    $('#notificationCount').text(0);
    setInterval(function(){
        console.log('lolo');
        $.ajax({
            url:'/notifications',
            method:'GET',
            success:function(res){
                if (res!=false) {
                    $('#notificationCount').text(res.length);
                    $('#notificationList').html('');
                    for (let i = 0; i < res.length; i++) {
                        $('#notificationList').append('<li class="text-left"><a href="/'+myotificationlink(res[i].msgType)+'" class="list-group-item list-group-item-action dropdown-item" aria-current="true"><div class="d-flex w-100 justify-content-between"><h5 class="mb-1"><i class="fa fa-bell mr-2" aria-hidden="true"></i>'+res[i].msg+'</h5><small>few Seconds ago</small></div><p class="mb-1">'+res[i].from+'</p></a></li')                        
                    };
                    
                }
            },
            error:function(err){
                alert(err)
            }
        })
    }, 5000);

    function myotificationlink(link) {
        switch(link) {
            case 'Order':
                console.log('link is'+link);
              return 'orders'
              break;
            case 'complete':
                console.log('link is'+link);
              return 'complete/orders'
              break;
            case 'complains':
                console.log('link is'+link);
              return 'worker/complains'
              break;
            
          }
    }

    $(document).on('click','.orderresponse',function(){
        var action = $(this).attr('data2')
        var orderNo = $(this).attr('data')

        $.ajax({
            url:'/order/response/'+orderNo+'/'+action,
            method:'GET',
            success:function(res){
                var x = '#id'+orderNo;
                if (res!=false) {
                    $('#result').html('<b class="alert alert-success">Congratulations! You Got A New Job</b>');
                    $(''+x).addClass('d-none');
                } else {
                    $('#result').html('<b class="alert alert-Danger">Rejected! You Rejected A New Job</b>');
                    $(''+x).addClass('d-none');
                }
            },
            error:function(err){
                alert(err)
            }
        })
    })

    $("#st1").click(function() {
        $(".fa-star").css("color", "black");
        $("#st1").css("color", "yellow");
        $('#stars').val($(this).attr('data'))

    });
    $("#st2").click(function() {
        $(".fa-star").css("color", "black");
        $("#st1, #st2").css("color", "yellow");
        $('#stars').val($(this).attr('data'))

    });
    $("#st3").click(function() {
        $(".fa-star").css("color", "black")
        $("#st1, #st2, #st3").css("color", "yellow");
        $('#stars').val($(this).attr('data'))

    });
    $("#st4").click(function() {
        $(".fa-star").css("color", "black");
        $("#st1, #st2, #st3, #st4").css("color", "yellow");
        $('#stars').val($(this).attr('data'))

    });
    $("#st5").click(function() {
        $(".fa-star").css("color", "black");
        $("#st1, #st2, #st3, #st4, #st5").css("color", "yellow");
        $('#stars').val($(this).attr('data'))

    });

    $('.complainModal').hide();

    $(document).on('click','.complain',function(){
        $('.complainModal').addClass('d-block');
        var worker = $(this).attr('data');
        var orderId = $(this).attr('data2');
        $('#worker').val(worker);
        $('#orderId').val(orderId);
    })

    $(document).on('click','#complainSubmit',function(){
        
        var worker = $('#worker').val();
        var complain = $('#complain').val();

        $.ajax({
            url:'/complain/'+worker+'/'+complain,
            method:'GET',
            success:function(res){
                $('.complainModal').hide();
                location.href = "https://eojp.herokuapp.com/order/history"
            },
            error:function(err){
                alert(err)
            }
        })
    })

    $(document).on('click','.modalClose',function(){
        $('.complainModal').removeClass('d-block');
        $('.complainModal').addClass('d-none');
    })
})

