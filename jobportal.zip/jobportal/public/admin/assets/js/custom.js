$(document).ready(function(){
    $(document).on('change','#service',function(){
        var service = $(this).val();
        $('#subservice').html('');
        $('#allsubservices').val('');
        $.ajax({
            url:'/admin/getsubservice/'+service,
            method:'GET',
            success:function(res){
                $('#subservice').append('<option selected disabled>Select Sub Service</option>')
                for (let i = 0; i < res.length; i++) {
                    $('#subservice').append('<option value="'+res[i].name+'" id="sub'+res[i]._id+'">' + res[i].name + '</option>')
                    
                }
            },
            error:function(err){
                console.log(err);
            }
        })
    })

    $(document).on('change','#subservice',function(){
        
        var subval = $(this).val();
        $('#allsubservices').val($('#allsubservices').val()+','+subval)
        
    })


    $(document).on('click','#modalbtnclose',function(){
        $('#workerModal').hide()
    })

    $('#workerModal').hide()
    $(document).on('click','#viewData',function(){
        var id = $(this).attr('data');
        $.ajax({
            url:'/admin/getworker/'+id,
            method:'GET',
            success:function(res){
                $('#workerModal').show();
                $('#workerImage').attr("src", "/images/"+res.image);
                $('#name').html('<b>Name:</b> '+ res.name);
                $('#Email').html('<b>Email:</b> '+ res.email);
                $('#service').html('<b>Service:</b> '+ res.service.name);
                $('#workerSubService').html('<b>Sub Services:</b> '+ res.subservice.toString());
                $('#DOB').html('<b>DOB: </b>'+ res.DOB);
                $('#Gender').html('<b>Gender: </b>'+ res.gender);
                $('#Phone').html('<b>Phone: </b>'+ res.phone);
                $('#CNIC').html('<b>CNIC: </b>'+ res.CNIC);
                $('#Bio').html('<b>Bio: </b>'+ res.bio);
                $('#Contact').html('<b>Contact: </b>'+ res.contact);
                $('#experience').html('<b>Experience: </b>'+ res.experience);
                $('#bankaccount').html('<b>Bank Account: </b>'+ res.bankaccount);
                $('#addedby').html('<b>Added By: </b>'+ res.addedby);
                $('#accountType').html('<b>Account Type: </b>'+ res.accountType);
                // $('#').text(res.);
                // $('#').text(res.);
                // $('#').text(res.);
                // $('#').text(res.);
            },
            error:function(err){
                console.log(err);
            }
        })
        
    })

    function myfunctionclick(name) {
        alert(name);
    }
})