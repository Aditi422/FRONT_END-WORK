const express = require('express');
const {check} = require('express-validator')
const upload = require('../server/middlewares/multer')
const AdminAuthController = require('../server/controllers/AdminAuthController')
const AdminActivityController = require('../server/controllers/ServiceController')
const SubServiceController = require('../server/controllers/SubServiceController')
const StaffCategory = require('../server/controllers/StaffCategoryController')
const WorkerController = require('../server/controllers/WorkerController')
// getting the admin model
const AdminModel = require('../server/models/Admin')

const authcheck = require('../server/middlewares/authcheckMiddleware')
//creating the router instance
const router = express.Router();

router.get('/',authcheck.alreadyLoggedInCheck,AdminAuthController.login)

//creating Admin with api
//using the post method to create a admin
router.post('/register',[upload.single('image'),
check('name').not().isEmpty().withMessage('Name Must be filled'),    
check('email').not().isEmpty().withMessage('Email Must be filled').isEmail().withMessage('Value Must be an Email'),    
check('DOB').not().isEmpty().withMessage('Must be Date'),    
check('gender').not().isEmpty().withMessage('Gender Must be filled'),   
check('contact').not().isEmpty().withMessage('Contact Must be filled'),  
],AdminAuthController.register)

router.post('/login',authcheck.alreadyLoggedInCheck,AdminAuthController.loginUser)
router.get('/signout',authcheck.checkLogin,AdminAuthController.signout)
router.get('/dashboard',authcheck.checkLogin,AdminAuthController.dashboard) // secured dashboard
router.get('/profile',authcheck.checkLogin,AdminAuthController.profile)

//admin activity handeler routes
router.get('/addservice',authcheck.checkLogin,AdminActivityController.addservice)
router.post('/storeservice',authcheck.checkLogin,AdminActivityController.storeservice)
router.get('/servicelist',authcheck.checkLogin,AdminActivityController.servicelist)
router.get('/edit-service/:id',authcheck.checkLogin,AdminActivityController.editservice)
router.post('/updateservice/',authcheck.checkLogin,AdminActivityController.updateservice)
router.get('/delete-service/:id',authcheck.checkLogin,AdminActivityController.deleteservice)

//admin sub service handeler routes
router.get('/addsubservice',authcheck.checkLogin,SubServiceController.addsubservice)
router.post('/storesubservice',authcheck.checkLogin,SubServiceController.storesubservice)
router.get('/subservicelist',authcheck.checkLogin,SubServiceController.subservicelist)
router.get('/edit-subservice/:id',authcheck.checkLogin,SubServiceController.editsubservice)
router.post('/updatesubservice/',authcheck.checkLogin,SubServiceController.updatesubservice)
router.get('/delete-subservice/:id',authcheck.checkLogin,SubServiceController.deletesubservice)

//staff category handeler routes
router.get('/addcategory',authcheck.checkLogin,StaffCategory.addcategory)
router.post('/storecategory',authcheck.checkLogin,StaffCategory.storecategory)
router.get('/categorylist',authcheck.checkLogin,StaffCategory.categorylist)
router.get('/edit-category/:id',authcheck.checkLogin,StaffCategory.editcategory)
router.post('/updatecategory/',authcheck.checkLogin,StaffCategory.updatecategory)
router.get('/delete-category/:id',authcheck.checkLogin,StaffCategory.deletecategory)

//create worker routes
router.get('/addworker',authcheck.checkLogin,WorkerController.addworker)
//using the post method to create a admin
router.post('/addworker',authcheck.checkLogin,[upload.single('image'),
    check('name').not().isEmpty().withMessage('Name Must be filled'),    
    check('email').not().isEmpty().withMessage('Email Must be filled').isEmail().withMessage('Value Must be an Email'),    
    check('phone').not().isEmpty().withMessage('Must be Filled').isLength({ min: 11}).withMessage("Phone no must be 11 Digits"),    
    check('password').not().isEmpty().withMessage('Must be Filled').isLength({ min: 6, max: 12 }).withMessage("Password must be between 6-12 charecter"),    
    check('DOB').not().isEmpty().withMessage('Must be Date'),    
    check('rate').not().isEmpty().withMessage('Rate Must be filled'),   
    check('gender').not().isEmpty().withMessage('Gender Must be filled'),   
    check('service').not().isEmpty().withMessage('Service Must be filled'),   
    check('allsubservices').not().isEmpty().withMessage('Sub Services Must be filled'),   
    check('contact').not().isEmpty().withMessage('Contact Must be filled'),  
    check('location').not().isEmpty().withMessage('Location Must be filled'),   
    check('CNIC').not().isEmpty().withMessage('CNIC Must be filled'),  
    check('experience').not().isEmpty().withMessage('Experience Must be filled'),   
    check('bankaccount').not().isEmpty().withMessage('Bankaccount Must be filled'),  
    check('bio').not().isEmpty().withMessage('Bio Must be filled'),  
    check('contact').not().isEmpty().withMessage('Contact Must be filled'),  
    ],WorkerController.workerregister)

router.get('/getsubservice/:id',authcheck.checkLogin,WorkerController.getSubservice) //ajax request to get sub services

router.get('/workerlist',authcheck.checkLogin,WorkerController.getAllWorker)
router.get('/getworker/:id',authcheck.checkLogin,WorkerController.getWorker)

router.get('/edit-worker/:id',authcheck.checkLogin,WorkerController.editWorker)
router.post('/updateworker',authcheck.checkLogin,[upload.single('image')],WorkerController.updateWorker)
router.get('/delete-worker/:id',authcheck.checkLogin,WorkerController.deleteWorker)

module.exports = router