const express = require('express')
const {check} = require('express-validator')
const FrontController = require('../server/controllers/FrontPageController')
const UserController = require('../server/controllers/UserController')
const WorkerController = require('../server/controllers/WorkerController')
const OrderController = require("../server/controllers/OrderController")
const NotificationController = require('../server/controllers/NotificationController')
const WorkerPaymentController = require('../server/controllers/WorkerPaymentController')
const upload = require('../server/middlewares/multer')



const router = express.Router()

router.get('/',FrontController.homePage)
router.get('/404',FrontController.errorpage)
router.get('/about',FrontController.about)
router.get('/contact',FrontController.contact)

//register route 
router.get('/register',UserController.register)
router.post('/register',[upload.single('image'),
check('name').not().isEmpty().withMessage('Name Must be filled'),    
check('email').not().isEmpty().withMessage('Email Must be filled').isEmail().withMessage('Value Must be an Email'),    
check('username').not().isEmpty().withMessage('Username Must be filled'),    
check('password').not().isEmpty().withMessage('Password Must be filled').isLength({ min: 6, max: 12 }).withMessage("Password must be between 6-12 charecter"),    
check('conpassword').not().isEmpty().withMessage('Confirm Password Must be filled'),    
check('gender').not().isEmpty().withMessage('Gender Must be filled'),  
],UserController.registerUser)

//user auth and details routes
router.get('/confirm/:token/:uid',UserController.confirmUser)
router.get('/login',UserController.login)
router.post('/login',UserController.userLogin)
router.get('/logout',UserController.logout)
router.get('/profile',UserController.profile)
router.get('/edit-profile/:Uid',UserController.editProfile)
router.post('/edit-profile',[upload.single('image'),
check('name').not().isEmpty().withMessage('Name Must be filled'),    
check('email').not().isEmpty().withMessage('Email Must be filled').isEmail().withMessage('Value Must be an Email'),    
check('username').not().isEmpty().withMessage('Username Must be filled'),    
check('gender').not().isEmpty().withMessage('Gender Must be filled'),  
],UserController.updateUser)

router.get('/forgot-password',UserController.forgetpass)
router.post('/forget-pass',UserController.orgetpasslinksend)
router.get('/reset/password/:token/:uid',UserController.confirmUserpass)
router.post('/new-pass',UserController.updatePass)
//worker auth and details routes
router.get('/workerlogin',WorkerController.loginpage)
router.post('/login/worker/',WorkerController.login)
router.get('/worker/profile',WorkerController.profile)
router.get('/worker/edit-profile/:id',WorkerController.editProfile)
router.post('/worker/edit-profile',[upload.single('image')],WorkerController.updateWorker)

//service subservice listing routes
router.get('/workerlist/:name',FrontController.subserviceWorkerList)
router.get('/details/:name',FrontController.workerDetails)
router.get('/service/workerlist/:name',FrontController.servicebasedWorker)

//front ajax code for finding worker based on sub category check list
router.get('/servicewise/subservice/worker/:service/:sub',FrontController.getWorkerBasedOnSubcategoryCheckbox)


//checkout page route
router.get('/checkout/:id',OrderController.checkout)
router.post('/checkout',OrderController.checkoutuser)
router.get('/order/check',OrderController.getOrders)
router.get('/order/history',OrderController.getOrdershistory)
router.get('/orders',OrderController.checkOrders)
router.get('/orders',OrderController.checkOrders)
router.get('/complete/orders',OrderController.completeOrders)
router.get('/orders/accept',OrderController.acceptedOrders)
router.get('/orders/reject',OrderController.rejectedOrders)
router.get('/order/response/:orderno/:action', OrderController.orderResponse)
router.get('/complete/job/:orderId/:worker',OrderController.completeOrder)

//notification routes
router.get('/notifications',NotificationController.getNotifications)
router.get('/notification/complains/handel',NotificationController.ComplainNotificationsHandel)
router.get('/notification/complete/handel',NotificationController.CompleteNotificationsHandel)
router.get('/notification/orders/handel',NotificationController.OrdersNotificationsHandel)

//review route
router.post('/review',OrderController.putReview)

//complain route
router.get('/complain/:worker/:complain',OrderController.complain)
router.get('/worker/complains',OrderController.complainslist)

// wroker earning details
router.get('/worker/earning/',WorkerPaymentController.getCurrentMonthSallary)


module.exports = router

