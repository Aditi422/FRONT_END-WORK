const mongoose = require('mongoose');

exports.db = async ()=>{
    await mongoose.connect('mongodb+srv://aditi:aditiHeroku123@cluster0.qx0oj.mongodb.net/job?retryWrites=true&w=majority', {
        useNewUrlParser: true, 
        useUnifiedTopology: true,
        retryWrites:true

    },(err,rez)=>{
        if (err) {
            console.log("Connection couldn't be stublished"+err);
        } else {
            console.log("Database connected");
        }
    })
}