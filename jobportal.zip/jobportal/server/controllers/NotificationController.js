const NotificationModel = require('../models/Notifications')

exports.getNotifications = async (req,res)=>{
    console.log(req.session._id);
    try {
        const notifications = await NotificationModel.find({toid:req.session.fuser._id,view:false})

        return res.send(notifications)
    } catch (error) {
        return res.send(false)
    }
}

exports.ComplainNotificationsHandel = async (req,res)=>{
    try {
        const handel = await NotificationModel.updateMany({toid:req.session.fuser._id,view:false,msgType:'complains'},{$set:{view:true}})
        console.log(handel);
        return true;
    } catch (error) {
        return false;
    }
}


exports.CompleteNotificationsHandel = async (req,res)=>{
    try {
        const handel = await NotificationModel.updateMany({toid:req.session.fuser._id,view:false,msgType:'complete'},{$set:{view:true}})
        console.log(handel);
        return true;
    } catch (error) {
        return false;
    }
}

exports.OrdersNotificationsHandel = async (req,res)=>{
    try {
        const handel = await NotificationModel.updateMany({toid:req.session.fuser._id,view:false,msgType:'Order'},{$set:{view:true}})
        console.log('handelde'+handel);
        return true;
    } catch (error) {
        return false;
    }
}