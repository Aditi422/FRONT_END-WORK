const {validationResult} = require('express-validator')
const WorkerModel = require('../models/Worker')
const ServiceModel = require('../models/Service') 
const SubServiceModel = require('../models/SubService') 
const bcrypt = require('bcrypt')
const {generateJWTtoken} = require('../utills/generateToken')

exports.addworker = async (req,res)=>{
    const services = await ServiceModel.find()
    res.render('admin/worker/addworker',{
        allservices:services,
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success',''),
        oldData:null,
        errorslist:null
    })
}

exports.getSubservice = async (req,res)=>{
    try {
        const subservices = await SubServiceModel.find({service:req.params.id})
        
        return res.send(subservices)
    } catch (error) {
        console.log(error);
        return res.redirect('/admin/404')
    }
}


exports.workerregister = async (req,res)=>{
    const errors = validationResult(req)
    console.log(errors);
    if (errors.errors.length > 0) {
        const services = await ServiceModel.find()

        return res.render('admin/worker/addworker',{
            oldData:req.body,
            allservices:services,
            errorslist:errors.mapped(),
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }
    try {
        
        const hashedPassword = await bcrypt.hash(req.body.password,10)
        const data = ''+req.body.allsubservices.substring(1)
        const subServices = data.split(',')
        await WorkerModel.create({
            'name':req.body.name,
            'email':req.body.email,
            'image':req.file.filename,
            'password':hashedPassword,
            'phone':req.body.phone,
            'contact':req.body.contact,
            'bio':req.body.bio,
            'location':req.body.location,
            'rate':req.body.rate,
            'service':req.body.service,
            'subservice':subServices,
            'DOB':req.body.DOB,
            'gender':req.body.gender,
            'CNIC':req.body.CNIC,
            'experience':req.body.experience,
            'bankaccount':req.body.bankaccount,
            'status':1,
            'addedby':'admin',
            'accountType':'Worker',
            'review':[],
            'complains':[],
        })

        req.flash('fl_success','Worker Added Successfully!')
        return res.redirect('/admin/addworker')
    } catch (error) {
        console.log(error);
    }
}


exports.getAllWorker = async (req,res)=>{
    try {
        const workers = await WorkerModel.find({}).select('-password')
        if (workers.length>0) {
            return res.render('admin/worker/workerlist',{
                workers:workers,
                fl_error:req.flash('fl_error',''),
                fl_success:req.flash('fl_success',''),
            })
        } else {
            return res.render('admin/worker/workerlist',{
                workers:null,
                fl_error:req.flash('fl_error',''),
                fl_success:req.flash('fl_success',''),
            })
        }
    } catch (error) {
        req.flash('fl_error','Something went wrong!')
        return res.render('admin/worker/workerlist')
    }
}

exports.getWorker = async (req,res)=>{
    try {
        const worker = await WorkerModel.findOne({_id:req.params.id}).populate({path:'service',model:'Service'})
        console.log(worker);
        return res.send(worker)
    } catch (error) {
        console.log(error);
        return res.redirect('/admin/404')
    }
}

exports.editWorker = async (req,res)=>{
    try {
        const services = await ServiceModel.find()
        const worker = await WorkerModel.findOne({_id:req.params.id})
        return res.render('admin/worker/editworker',{
            allservices:services,
            worker:worker,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success','')
        })
    } catch (error) {
        console.log(error);
        return res.redirect('/admin/404')
    }
}

exports.updateWorker = async (req,res)=>{

    const subServices = req.body.subservices.split(',')
    try {
        if (req.body.password=='' && req.file==undefined) {
            //if both fields are not available
            const wrkr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'name':req.body.name,
                'email':req.body.email,
                'phone':req.body.phone,
                'contact':req.body.contact,
                'bio':req.body.bio,
                'location':req.body.location,
                'rate':req.body.rate,
                'service':req.body.service,
                'subservice':subServices,
                'DOB':req.body.DOB,
                'gender':req.body.gender,
                'CNIC':req.body.CNIC,
                'experience':req.body.experience,
                'bankaccount':req.body.bankaccount,
            })
        }
        if (req.body.password!='' &&req.file==undefined) {
            //only password is available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            const wrkr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'name':req.body.name,
                'email':req.body.email,
                'phone':req.body.phone,
                'password':hashedPassword,//if image is not availble but password availble
                'contact':req.body.contact,
                'bio':req.body.bio,
                'location':req.body.location,
                'rate':req.body.rate,
                'service':req.body.service,
                'subservice':subServices,
                'DOB':req.body.DOB,
                'gender':req.body.gender,
                'CNIC':req.body.CNIC,
                'experience':req.body.experience,
                'bankaccount':req.body.bankaccount,
            })
        }

        if (req.body.password=='' && req.file!=undefined) {
            //only image is available
            const wrkr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'name':req.body.name,
                'email':req.body.email,
                'phone':req.body.phone,
                'image':req.file.filename, //if password is not availble but image availble
                'contact':req.body.contact,
                'bio':req.body.bio,
                'location':req.body.location,
                'rate':req.body.rate,
                'service':req.body.service,
                'subservice':subServices,
                'DOB':req.body.DOB,
                'gender':req.body.gender,
                'CNIC':req.body.CNIC,
                'experience':req.body.experience,
                'bankaccount':req.body.bankaccount,
            })
        }

        if (req.body.password!='' && req.file!=undefined) {
            //both files are available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            const wrkr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'name':req.body.name,
                'email':req.body.email,
                'phone':req.body.phone,
                'password':hashedPassword,// if both inputs are availble then update both fields
                'image':req.file.filename,// if both inputs are availble then update both fields
                'contact':req.body.contact,
                'bio':req.body.bio,
                'location':req.body.location,
                'rate':req.body.rate,
                'service':req.body.service,
                'subservice':subServices,
                'DOB':req.body.DOB,
                'gender':req.body.gender,
                'CNIC':req.body.CNIC,
                'experience':req.body.experience,
                'bankaccount':req.body.bankaccount,
            })
        }
        req.flash('fl_success','Worker Updated Successfully!')
        return res.redirect('/admin/workerlist')
    } catch (error) {
        console.log(error);
        req.flash('fl_error','Worker Updated Failed!')
        return res.redirect('/admin/workerlist')
    }
}

exports.deleteWorker = async (req,res)=>{
    try {
        await WorkerModel.findOneAndDelete(req.params.id)
        req.flash('fl_success','Worker Deleted Successfully!')
        return res.redirect('/admin/workerlist')
    } catch (error) {
        console.log(error);
        return res.redirect('/admin/404')
    }
}

/**

From here all the codes for frontend part of the worker is done

all this is comming from the worker fronted section

*/

exports.loginpage = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/worker/workerlogin',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success',''),
        SubAndServices:SubAndServices,
        oldData:null,
        errorslist:null
    })
}

exports.login = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    if (req.body.email=='' || req.body.password=='') {
        req.flash('fl_error','All fields are required!')
        return res.render('front/workerlogin',{
            oldData:req.body,
            errorslist:null,
            SubAndServices:SubAndServices,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }
    try {

        const checkUser = await WorkerModel.findOne({email:req.body.email,status:1})
        if (checkUser!=null) {
            const match = await bcrypt.compare(req.body.password, checkUser.password);
            if(match) {
                req.session.jwttoken = await generateJWTtoken(checkUser._id)
                req.session.fuser = checkUser

                req.flash('fl_success','Successfully logged in!!');
                return res.redirect('/');
            }else{
                req.flash('fl_error','Wrong Credentials!!');
                return res.redirect('/workerlogin');
            }
        } else {
            req.flash('fl_error','Wrong Information!');
            return res.redirect('/workerlogin'); 
        }
    } catch (error) {
        console.log(error);
        req.flash('fl_error','Something Went Wrong Try again!');
        return res.redirect('/workerlogin');
    }
} 

exports.profile = async(req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const user = await WorkerModel.findOne({_id:req.session.fuser._id}).populate({path:'service',model:'Service'})
        console.log(user);
        return res.render('front/worker/profile',{
            fuser: user,
            SubAndServices:SubAndServices,
        })
    } catch (error) {
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}

exports.editProfile = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const profile = await WorkerModel.findOne({_id:req.params.id})
        return res.render('front/worker/editprofile',{
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
            SubAndServices:SubAndServices,
            oldData:profile,
            errorslist:null
        }) 
    } catch (error) {
        console.log(error);
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}

exports.updateWorker = async (req,res)=>{

    try {
        if (req.body.password=='' && req.file==undefined) {
            //if both fields are not available
            profileUsr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'location': req.body.location,
            })
        }
        if (req.body.password!='' &&req.file==undefined) {
            //only password is available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            profileUsr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'password': hashedPassword,
                'location': req.body.location,
            })
        }

        if (req.body.password=='' && req.file!=undefined) {
            //only image is available
            profileUsr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'image': req.file.filename,
                'location': req.body.location,
            })
        }

        if (req.body.password!='' && req.file!=undefined) {
            //both files are available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            profileUsr = await WorkerModel.findByIdAndUpdate(req.body.id,{
                'image': req.file.filename,
                'password': hashedPassword,
                'location': req.body.location,
            })
        }
        req.flash('fl_success','Updated Successfully!')
        return res.redirect('/worker/profile')
    } catch (error) {
        console.log(error);
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}



exports.logout = async (req,res)=>{
    req.session.destroy();
    return res.redirect('/')
}