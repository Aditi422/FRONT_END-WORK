const AdminModel = require('../models/Admin')
const {validationResult} = require('express-validator')
const bcrypt = require('bcrypt')
var crypto = require("crypto");
const {generateJWTtoken} = require('../utills/generateToken')
//route describe
exports.login = (req,res)=>{
    
    res.render('admin/login',{xError:{
            status:null,
            msg:'',
        },fl_msg:req.flash('fl_msg','')})
}


exports.dashboard = async (req,res)=>{

    try {
        console.log(req.session.user);
        return res.render('admin/dashboard');
    } catch (error) {
        console.log(error);
    }
}

//registering the admin using the api call
exports.register = async (req,res)=>{
    const errors = validationResult(req)
    if (errors.errors.length > 0) {
        return res.json({success: false, errors:'Something wrong! try again later' });
    }

    try {
        //hashed password 
        const hashedPassword = await bcrypt.hash(req.body.password,10)

        const x = await AdminModel.create({
                "name":req.body.name,
                "email":req.body.email,
                "DOB":req.body.DOB,
                "image":req.file.filename,
                "gender":req.body.gender,
                "password":hashedPassword,
                "CNIC":crypto.randomBytes(8).toString('hex'),
                "verifyToken":crypto.randomBytes(20).toString('hex'),
                "status":0,
                "contact":req.body.contact
             
        })
        return res.json({success: true, errors:'Admin Created Successfully'});
    } catch (error) {
        return res.json({success: false, errors:'Something wrong! try again later'});
    }
}

exports.loginUser = async (req,res)=>{
    //checking for empty submission
    if (req.body.email=='' || req.body.password=='') {
        req.flash('fl_msg','all fields are required');
        return res.redirect('/admin/');
    } else {
        //checking for valid password
        if (req.body.password.length< 6 || req.body.password.length>12) {
            req.flash('fl_msg','Password must be in between 6-12 charecter');
            return res.redirect('/admin/');
        }
        try {
            const user = await AdminModel.findOne({email:req.body.email })
            
            //matching the dcrypted password
            const match = await bcrypt.compare(req.body.password, user.password);
            if(match) {
                req.session.jwttoken = await generateJWTtoken(user._id)
                req.session.user = user

                req.flash('fl_msg','Successfully logged in!!');
                return res.redirect('/admin/dashboard');
            }else{
                req.flash('fl_msg','Wrong Credentials!!');
                return res.redirect('/admin/');
            }
        } catch (error) {
            console.log(error);
            req.flash('fl_msg','Wrong Credentials!!');
            return res.redirect('/admin/');
            
        }
    }
}


exports.signout = (req,res)=>{
    req.session.destroy();
    return res.redirect('/admin/')
}

exports.profile = (req,res)=>{
    return res.render('admin/profile')
}