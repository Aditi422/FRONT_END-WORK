const OrderModel = require('../models/Order')
const SubServiceModel = require('../models/SubService')

exports.getCurrentMonthSallary = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        var mL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const orders = await OrderModel.find({worker:req.session.fuser._id,status:4})
        console.log(orders);
        return res.render('front/worker/payMonth',{
            SubAndServices:SubAndServices,
            orders:orders,
            months:mL
        })
    } catch (error) {
        console.log();
    }
}