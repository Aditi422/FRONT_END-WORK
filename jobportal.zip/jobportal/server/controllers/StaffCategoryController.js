const AdminModel = require('../models/Admin')
const {validationResult} = require('express-validator')
const crypto = require('crypto')
//model import 
const categoryModel = require('../models/StaffCategory')

exports.addcategory = (req,res)=>{
    return res.render('admin/staffcategory/addcategory',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success','')
    })
}

exports.storecategory = async (req,res)=>{
    if(req.body.categoryname==''){
        req.flash('fl_error','All fields are required!')
        return res.redirect('/admin/addcategory')
    }

    try {
        await categoryModel.create({
            name:req.body.categoryname,
            categoryid:crypto.randomBytes(12).toString('hex'),
            status:true
        })
        req.flash('fl_success','Service Created!')
        return res.redirect('/admin/addcategory')
    } catch (error) {
        req.flash('fl_error','Somthing went wrong!')
        return res.redirect('/admin/addcategory')
    }

}

exports.categorylist = async (req,res)=>{
    try {
        const categories = await categoryModel.find({})
        if (categories.length<=0) {
            return res.render('admin/staffcategory/categorylist',{
                allcategories:null
            })
        } else {
            return res.render('admin/staffcategory/categorylist',{
                allcategories:categories
            })
        }
    } catch (error) {
        console.log(error);
        req.flash('fl_error','No service Availble now!')
        return res.redirect('/admin/categorylist')
    }
}

exports.editcategory = async(req,res)=>{
    try {
        const category = await categoryModel.findOne({_id:req.params.id})
        return res.render('admin/staffcategory/editcategory',{category:category,fl_error:req.flash('fl_error',''),fl_success:req.flash('fl_success','')})
    } catch (error) {
        return res.redirect('/admin/404')
    }
}

exports.updatecategory = async (req,res)=>{
    try {
        await categoryModel.findByIdAndUpdate(req.body.id,{
            name:req.body.categoryname
        })

        req.flash('fl_success','Service Updated!')
        return res.redirect('/admin/categorylist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/categorylist')
    }
}

exports.deletecategory = async (req,res)=>{
    try {
        await categoryModel.findByIdAndDelete(req.params.id)

        req.flash('fl_success','Service Deleted!')
        return res.redirect('/admin/categorylist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/categorylist')
    }
}