const AdminModel = require('../models/Admin')
const {validationResult} = require('express-validator')
const crypto = require('crypto')
//model import 
const ServiceModel = require('../models/Service')
const SubServiceModel = require('../models/SubService')

exports.addsubservice = async (req,res)=>{
    const services = await ServiceModel.find({})
    if (services.length<=0) {
        return res.render('admin/subservices/addsubservice',{
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
            serviceslist:null
        })
    } else {
        return res.render('admin/subservices/addsubservice',{
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
            serviceslist:services
        })
    }
}

exports.storesubservice = async (req,res)=>{
    if(req.body.subservicename=='' || req.body.service==''){
        req.flash('fl_error','All fields are required!')
        return res.redirect('/admin/addsubservice')
    }

    try {
        const service = await SubServiceModel.create({
            service:req.body.service,
            name:req.body.subservicename,
            subserviceid:crypto.randomBytes(12).toString('hex'),
            status:true
        })
        req.flash('fl_success','Sub Service Created!')
        return res.redirect('/admin/addsubservice')
    } catch (error) {
        req.flash('fl_error','Somthing went wrong!')
        return res.redirect('/admin/addsubservice')
    }

}

exports.subservicelist = async (req,res)=>{
    try {
        const subservices = await SubServiceModel.find({}).populate({path:'service',model:'Service'})
        
        if (subservices.length<=0) {
            return res.render('admin/subservices/subservicelist',{
                allservices:null,fl_error:req.flash('fl_error',''),fl_success:req.flash('fl_success','')
            })
        } else {
            return res.render('admin/subservices/subservicelist',{
                allservices:subservices,fl_error:req.flash('fl_error',''),fl_success:req.flash('fl_success','')
            })
        }
    } catch (error) {
        
        req.flash('fl_error','No service Availble now!')
        return res.redirect('/admin/subservicelist')
    }
}

exports.editsubservice = async(req,res)=>{
    try {
        const services = await ServiceModel.find({})
        const subservice = await SubServiceModel.findOne({_id:req.params.id})
        return res.render('admin/subservices/editsubservice',{subservice:subservice,serviceslist:services,fl_error:req.flash('fl_error',''),fl_success:req.flash('fl_success','')})
    } catch (error) {
        console.log(error);
        return res.redirect('/admin/404')
    }
}

exports.updatesubservice = async (req,res)=>{
    try {
        await SubServiceModel.findByIdAndUpdate(req.body.id,{
            service:req.body.service,
            name:req.body.subservicename
        })

        req.flash('fl_success','Sub Service Updated!')
        return res.redirect('/admin/subservicelist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/subservicelist')
    }
}

exports.deletesubservice = async (req,res)=>{
    try {
        await SubServiceModel.findByIdAndDelete(req.params.id)

        req.flash('fl_success','Service Deleted!')
        return res.redirect('/admin/subservicelist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/subservicelist')
    }
}