const OrderModel = require('../models/Order')
const SubServiceModel = require('../models/SubService')
const WorkerModel = require('../models/Worker')
const {validationResult} = require('express-validator')
var crypto = require("crypto");
const NotificationModel = require('../models/Notifications');



exports.checkout = async (req,res)=>{
    try {
        const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
        const worker = await WorkerModel.findOne({_id:req.params.id})
        return res.render('front/checkout',{
            worker:worker,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}

exports.checkoutuser = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const entrydate = new Date().toLocaleDateString();
        const orderId = crypto.randomBytes(12).toString('hex')
        await OrderModel.create({
            employer:req.session.fuser._id,
            worker:req.body.workrer,
            totalamount:req.body.rate*req.body.hours,
            rate:req.body.rate,
            date:req.body.date,
            shift:req.body.shift,
            hours:req.body.hours,
            details:req.body.details,
            orderNo:orderId,
            createdAt:entrydate,
            status:1,
        })

        await NotificationModel.create({
            'from':req.session.fuser.name,
            'fromid':req.session.fuser._id,
            'to':req.body.workrername,
            'toid':req.body.workrer,
            'orderId':orderId,
            'msg':'New Order Arrived!',
            'msgType':'Order',
        })

        return res.render('front/done',{
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}

exports.getOrders = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({employer:req.session.fuser._id,status:{$in:[1,2,3]}}).populate({path:'worker',select:'-password',model:'Worker'})
        console.log(orders);
        return res.render('front/orders',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}

exports.getOrdershistory = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({employer:req.session.fuser._id,status:4}).populate({path:'worker',select:'-password',model:'Worker'})
        console.log(orders);
        return res.render('front/ordershistory',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}

exports.checkOrders = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({worker:req.session.fuser._id,status:1}).populate({path:'employer',select:'-password',model:'User'})
        console.log('orders are'+orders);
        return res.render('front/worker/orders',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}

exports.completeOrders = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({worker:req.session.fuser._id,status:4}).populate({path:'employer',select:'-password',model:'User'})
        console.log('orders are'+orders);
        return res.render('front/worker/completeorders',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}
exports.acceptedOrders = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({worker:req.session.fuser._id,status:2}).populate({path:'employer',select:'-password',model:'User'})
        return res.render('front/worker/acceptedorders',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}


exports.rejectedOrders = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const orders = await OrderModel.find({worker:req.session.fuser._id,status:3}).populate({path:'employer',select:'-password',model:'User'})
        console.log('orders are'+orders);
        return res.render('front/worker/rejectedorders',{
            orders:orders,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        console.log(error);
    }
}


exports.orderResponse = async (req,res)=>{
    
    try {
        if (req.params.action=='accept') {
            await OrderModel.findOneAndUpdate({orderNo:req.params.orderno},{status:2})
        } else {
            await OrderModel.findOneAndUpdate({orderNo:req.params.orderno},{status:3})
        }
        
        return res.send(true)
    } catch (error) {
        res.send(false)
    }


}

exports.completeOrder = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        await OrderModel.findOneAndUpdate({orderNo:req.params.orderId},{status:4})
        await NotificationModel.create({
            'from':req.session.fuser.name,
            'fromid':req.session.fuser._id,
            'to':'worker',
            'toid':req.params.worker,
            'orderId':req.params.orderId,
            'msg':'Order Marked As Complete!',
            'msgType':'complete',
        })
        return res.render('front/review',{SubAndServices:SubAndServices,worker:req.params.worker})
    } catch (error) {
        
    }
}

exports.putReview = async (req,res)=>{
    const entrydate = new Date().toLocaleDateString();
    try {
        const worker = await WorkerModel.findByIdAndUpdate(req.body.worker,{$push:{review:{user:req.session.fuser.name,stars:req.body.stars,comment:req.body.review,date:entrydate}}})

        res.redirect('/order/history')
    } catch (error) {
        console.log(error);
    }
}

exports.complain = async (req,res)=>{
    const entrydate = new Date().toLocaleDateString();
    try {
        const worker = await WorkerModel.findByIdAndUpdate(req.params.worker,{$push:{complains:{user:req.session.fuser.name,userId:req.session.fuser._id,orderId:req.body.orderId,comaplainId:crypto.randomBytes(12).toString('hex'),comment:req.params.complain,date:entrydate}}})

        await NotificationModel.create({
            'from':req.session.fuser.name,
            'fromid':req.session.fuser._id,
            'to':'worker',
            'toid':req.params.worker,
            'orderId':req.params.orderId,
            'msg':'A complain Has Placed Against You!',
            'msgType':'complains',
        })

        res.send(true)
    } catch (error) {
        console.log(error);
        res.send(false)
    }
}

exports.complainslist = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})

    try {
        const worker = await WorkerModel.findOne({_id:req.session.fuser._id})
       
        return res.render('front/worker/complains',{SubAndServices:SubAndServices,worker:worker})
    } catch (error) {
        console.log(error);
    }
}