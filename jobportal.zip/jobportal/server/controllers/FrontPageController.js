const ServiceModel = require('../models/Service')
const SubServiceModel = require('../models/SubService')
const WorkerModel = require('../models/Worker')
const {validationResult} = require('express-validator')

exports.homePage = async (req,res)=>{

    const Services = await ServiceModel.find()
    const SubServices = await SubServiceModel.find()
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    const Workers = WorkerModel.find().select('-password')
    if (req.session.fuser!=undefined) {
        const profile = await WorkerModel.findOne({_id:req.session.fuser._id})
        return res.render('front/home',{
            SubAndServices:SubAndServices,
            services:Services,
            subServices:SubServices,
            workers:Workers,
            profile:profile,
        })
    } else {
        return res.render('front/home',{
            services:Services,
            subServices:SubServices,
            workers:Workers,
            fuser:null,
            SubAndServices:SubAndServices,
        })
    }
}


exports.errorpage = (req,res)=>{
    return res.render('front/404')
}

exports.about = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/about',{SubAndServices:SubAndServices})
}

exports.contact = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/contact',{SubAndServices:SubAndServices})
}

exports.subserviceWorkerList = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        
        const workers = await WorkerModel.find({status:1,subservice:{$in:[req.params.name]} }).select('-password')
        if (workers.length>0) {
            return res.render('front/workerlist',{
                workers:workers,
                SubAndServices:SubAndServices
            })
        } else {
            return res.render('front/workerlist',{
                workers:null,
                SubAndServices:SubAndServices
            }) 
        }
    } catch (error) {
        return res.render('front/workerlist',{
            workers:null,
            SubAndServices:SubAndServices
        })
    }
}

exports.workerDetails = async (req,res)=>{
    try {
        const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
        const worker = await WorkerModel.findOne({name:req.params.name,status:1}).populate({path:'service',model:'Service'}).select('-password')
        return res.render('front/workerdetails',{
            worker:worker,
            SubAndServices:SubAndServices
        })
    } catch (error) {
        return res.redirect('/404')
    }
}

exports.servicebasedWorker = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const workers = await WorkerModel.find({status:1}).populate({path:'service',model:'Service'}).select('-password')

        return res.render('front/serviceworkerlist',{
            workers:workers,
            serviceName:req.params.name,
            SubAndServices:SubAndServices    
        })
    } catch (error) {
        return res.redirect('/404')
    }
}


exports.getWorkerBasedOnSubcategoryCheckbox = async (req,res)=>{
    try {
        const workers = await WorkerModel.find({service:req.params.service,subservice:{$in:[req.params.sub]}}) 
        res.send(workers)
    } catch (error) {
        res.send(false)
    }
}
