const AdminModel = require('../models/Admin')
const {validationResult} = require('express-validator')
const crypto = require('crypto')
//model import 
const servicesModel = require('../models/Service')

exports.addservice = (req,res)=>{
    return res.render('admin/services/addservice',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success','')
    })
}

exports.storeservice = async (req,res)=>{
    if(req.body.servicename==''){
        req.flash('fl_error','All fields are required!')
        return res.redirect('/admin/addservice')
    }

    try {
        const service = await servicesModel.create({
            name:req.body.servicename,
            serviceid:crypto.randomBytes(12).toString('hex'),
            status:true
        })
        req.flash('fl_success','Service Created!')
        return res.redirect('/admin/addservice')
    } catch (error) {
        req.flash('fl_error','Somthing went wrong!')
        return res.redirect('/admin/addservice')
    }

}

exports.servicelist = async (req,res)=>{
    try {
        const services = await servicesModel.find({})
        if (services.length<=0) {
            return res.render('admin/services/servicelist',{
                allservices:null
            })
        } else {
            return res.render('admin/services/servicelist',{
                allservices:services
            })
        }
    } catch (error) {
        req.flash('fl_error','No service Availble now!')
        return res.redirect('/admin/servicelist')
    }
}

exports.editservice = async(req,res)=>{
    try {
        const service = await servicesModel.findOne({_id:req.params.id})
        return res.render('admin/services/editservice',{service:service,fl_error:req.flash('fl_error',''),fl_success:req.flash('fl_success','')})
    } catch (error) {
        return res.redirect('/admin/404')
    }
}

exports.updateservice = async (req,res)=>{
    try {
        await servicesModel.findByIdAndUpdate(req.body.id,{
            name:req.body.servicename
        })

        req.flash('fl_success','Service Updated!')
        return res.redirect('/admin/servicelist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/servicelist')
    }
}

exports.deleteservice = async (req,res)=>{
    try {
        await servicesModel.findByIdAndDelete(req.params.id)

        req.flash('fl_success','Service Deleted!')
        return res.redirect('/admin/servicelist')
    } catch (error) {
        req.flash('fl_error','Something went wrong try again later!')
        return res.redirect('/admin/servicelist')
    }
}