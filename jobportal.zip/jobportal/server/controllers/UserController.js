const {validationResult} = require('express-validator')
const UserModel = require('../models/User')
const SubServiceModel = require('../models/SubService')
const bcrypt = require('bcrypt')
var crypto = require("crypto");
const {generateJWTtoken} = require('../utills/generateToken')
//node mailer middleware for reuse import
const mainfunction = require('../middlewares/nodemailerMiddleware')
const passwordmailer = require('../middlewares/passwordmailerMiddleware')

exports.register = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/register',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success',''),
        SubAndServices:SubAndServices,
        oldData:null,
        errorslist:null
    })
}

exports.registerUser = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    const errors = validationResult(req)
    
    if (errors.errors.length > 0) {

        return res.render('front/register',{
            oldData:req.body,
            errorslist:errors.mapped(),
            SubAndServices:SubAndServices,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }
    
    if (req.body.password!==req.body.conpassword) {
        req.flash('fl_error','Password didn\'t matched!')
        return res.render('front/register',{
            oldData:req.body,
            errorslist:null,
            SubAndServices:SubAndServices,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }

    if (req.file==undefined) {
        req.flash('fl_error','Image is required!')
        return res.render('front/register',{
            oldData:req.body,
            errorslist:null,
            SubAndServices:SubAndServices,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }
    const emailcheck = await UserModel.findOne({'email':req.body.email})
    if (emailcheck!=null) {
        req.flash('fl_error','Email address Already Exists!')
        return res.render('front/register',{
            oldData:req.body,
            errorslist:null,
            SubAndServices:SubAndServices,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }

    try {
        
        const hashedPassword = await bcrypt.hash(req.body.password,10)
        const confirmationtoken = crypto.randomBytes(8).toString('hex')
        const Uid = crypto.randomBytes(8).toString('hex')
        await UserModel.create({
            'name': req.body.name,
            'email': req.body.email,
            'image': req.file.filename,
            'username': req.body.username,
            'password': hashedPassword,
            'phone': req.body.phone,
            'Uid': Uid,
            'gender': req.body.gender,
            'status': false,
            'location': req.body.location,
            'confirmationtoken': confirmationtoken,
        })
        const userObject ={
            'name':req.body.name,
            'email':req.body.email,
            'confirmationToken':confirmationtoken,
            'uid':Uid
        }
        const mailData = new mainfunction(userObject)

        req.flash('fl_success','A activation link has been sent to '+req.body.email+'. Activate Now');
        return res.redirect('/login');
    } catch (error) {
        console.log(error);
        req.flash('fl_error','Registration Failed! Try Again');
        return res.redirect('/register'); 
    }
}

exports.login = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/userlogin',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success',''),
        oldData:null,
        SubAndServices:SubAndServices,
    })
}

exports.userLogin = async (req,res)=>{
    try {
        const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    } catch (error) {
        console.log(error);
    }
    if (req.body.email=='' || req.body.password=='') {
        req.flash('fl_error','All fields are required!')
        return res.render('front/userlogin',{
            oldData:req.body,
            SubAndServices:SubAndServices,
            errorslist:null,
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
        })
    }
    try {
        // console.log(req.body);
        const checkUser = await UserModel.findOne({email:req.body.email,status:true})
        // console.log(checkUser);
        if (checkUser!=null) {
            const match = await bcrypt.compare(req.body.password, checkUser.password);
            if(match) {
                req.session.jwttoken = await generateJWTtoken(checkUser._id)
                req.session.fuser = checkUser

                req.flash('fl_success','Successfully logged in!!');
                return res.redirect('/');
            }else{
                req.flash('fl_error','Wrong Credentials!!');
                return res.redirect('/login');
            }
        } else {
            req.flash('fl_error','Wrong Information!');
            return res.redirect('/login'); 
        }
    } catch (error) {
        console.log(error);
        req.flash('fl_error','Something Went Wrong Try again!');
        return res.redirect('/login');
    }
}


exports.confirmUser = async (req,res)=>{
    try {
        const user = await UserModel.findOne({confirmationtoken:req.params.token,Uid:req.params.uid})
        if (user!=null) {
            await UserModel.findByIdAndUpdate(user._id,{status:true,confirmationtoken:crypto.randomBytes(8).toString('hex')})
            req.flash('fl_success','Successfully Activated!! Now Login');
            return res.redirect('/login');
        } else {
            req.flash('fl_error','Link Not valid or expired!');
            return res.redirect('/login');
        }
    } catch (error) {
        req.flash('fl_error','Something Went Wrong!');
        return res.redirect('/login');
    }
}

exports.profile = async(req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const user = await UserModel.findOne({_id:req.session.fuser._id})

        return res.render('front/profile',{
            profile: user,
            SubAndServices:SubAndServices,
        })
    } catch (error) {
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}


exports.editProfile = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const profile = await UserModel.findOne({Uid:req.params.Uid})
        return res.render('front/editprofile',{
            fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),
            oldData:profile,
            SubAndServices:SubAndServices,
            errorslist:null
        }) 
    } catch (error) {
        console.log(error);
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}

exports.updateUser = async (req,res)=>{
    if (req.body.location=='') {
        req.body.location='Bangladesh'
    }
    let profileUsr={};
    try {
        if (req.body.password=='' && req.file==undefined) {
            //if both fields are not available
            profileUsr = await UserModel.findByIdAndUpdate(req.body.id,{
                'name': req.body.name,
                'email': req.body.email,
                'username': req.body.username,
                'phone': req.body.phone,
                'gender': req.body.gender,
                'location': req.body.location,
            })
        }
        if (req.body.password!='' &&req.file==undefined) {
            //only password is available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            profileUsr = await UserModel.findByIdAndUpdate(req.body.id,{
                'name': req.body.name,
                'email': req.body.email,
                'username': req.body.username,
                'password': hashedPassword,
                'phone': req.body.phone,
                'gender': req.body.gender,
                'location': req.body.location,
            })
        }

        if (req.body.password=='' && req.file!=undefined) {
            //only image is available
            profileUsr = await UserModel.findByIdAndUpdate(req.body.id,{
                'name': req.body.name,
                'email': req.body.email,
                'image': req.file.filename,
                'username': req.body.username,
                'phone': req.body.phone,
                'gender': req.body.gender,
                'location': req.body.location,
            })
        }

        if (req.body.password!='' && req.file!=undefined) {
            //both files are available
            const hashedPassword = await bcrypt.hash(req.body.password,10)
            profileUsr = await UserModel.findByIdAndUpdate(req.body.id,{
                'name': req.body.name,
                'email': req.body.email,
                'image': req.file.filename,
                'username': req.body.username,
                'password': hashedPassword,
                'phone': req.body.phone,
                'gender': req.body.gender,
                'location': req.body.location,
            })
        }
        const userData = await UserModel.findOne({_id:req.body.id})
        req.session.fuser = userData
        req.flash('fl_success','User Updated Successfully!')
        return res.redirect('/profile')
    } catch (error) {
        console.log(error);
        req.flash('fl_error','User Updated Failed!')
        return res.redirect('/404')
    }
}

exports.logout = async (req,res)=>{
    req.session.destroy();
    return res.redirect('/')
}



exports.forgetpass = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    return res.render('front/forgetpass',{
        fl_error:req.flash('fl_error',''),
        fl_success:req.flash('fl_success',''),
        oldData:null,
        SubAndServices:SubAndServices,
    })
}

exports.orgetpasslinksend = async (req,res)=>{

    try {
        const checkuser = await UserModel.findOne({email:req.body.email})
        console.log(checkuser);
        const userObject ={
            'name':checkuser.name,
            'email':req.body.email,
            'confirmationToken':checkuser.confirmationtoken,
            'uid':checkuser.Uid
        }
        const mailData = new passwordmailer(userObject)
        console.log(mailData);
        req.flash('fl_success','A Password reset link has been sent to '+req.body.email+'. Activate Now');
        return res.redirect('/forgot-password');

    } catch (error) {
        console.log(error);
        req.flash('fl_error','No user Found!!');
        return res.redirect('/forgot-password');
    }


}

exports.confirmUserpass = async (req,res)=>{
    const SubAndServices = await SubServiceModel.find().populate({path:'service',model:'Service'})
    try {
        const user = await UserModel.findOne({confirmationtoken:req.params.token,Uid:req.params.uid})
        if (user!=null) {
            // await UserModel.findByIdAndUpdate(user._id,{status:true,confirmationtoken:crypto.randomBytes(8).toString('hex')})
            // req.flash('fl_success','Successfully Activated!! Now Login');
            return res.render('front/addpass',{id:user._id,SubAndServices:SubAndServices,fl_error:req.flash('fl_error',''),
            fl_success:req.flash('fl_success',''),});
        } else {
            req.flash('fl_error','Link Not valid or expired!');
            return res.redirect('/login');
        }
    } catch (error) {
        req.flash('fl_error','Something Went Wrong!');
        return res.redirect('/login');
    }
}

exports.updatePass = async (req,res)=>{
    try {
        const hashedPassword = await bcrypt.hash(req.body.password,10)
        const confirmationtoken = crypto.randomBytes(8).toString('hex')
        profileUsr = await UserModel.findByIdAndUpdate(req.body.id,{
            'password': hashedPassword,
            'confirmationtoken': confirmationtoken,
        })
        req.flash('fl_success','Password reset Successful');
        return res.redirect('/login')
    } catch (error) {
        console.log(error);
        req.flash('fl_error','Something Went Wrong. Try again!!')
        return res.redirect('/404')
    }
}