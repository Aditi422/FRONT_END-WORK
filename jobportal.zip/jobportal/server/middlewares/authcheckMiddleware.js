const jwt = require('jsonwebtoken')

exports.checkLogin = (req,res,next) => {
    const token = req.session.jwttoken
    if (token==undefined) {
        res.redirect('/admin')
    } else {
        jwt.verify(token,'$2b$10$M5/.BBn0yWK91XqQcVpTY5FT54YTjcEyJMT9Rb1ldEPXnp/hhqYi0hzPO',function(err, decoded) {
            if (err) {
                console.log(err);
                res.redirect('/admin')
            } else {
                req.session.id = decoded.id
                next()
            }
          });
        
    }
}


exports.alreadyLoggedInCheck = (req,res,next)=>{
    const token = req.session.jwttoken
    if (token!=undefined) {
        return res.redirect('/admin/dashboard')
    } else {
        next()
    }
    // if (token==undefined) {
    //     res.redirect('/admin')
    // } else {
    //     jwt.verify(token,process.env.JWT_TOKEN_SECRET_KEY,function(err, decoded) {
    //         if (err) {
    //             res.redirect('/admin')
    //         } else {
    //             res.redirect('/admin/dashboard')
    //             next()
    //         }
    //     });
        
    // }
}