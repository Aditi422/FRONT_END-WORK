const nodemailer = require('nodemailer')

// async..await is not allowed in global scope, must use a wrapper
function mainfunction(data) {
    console.log('all data is: '+data.name);
    async function main(){
        // Generate test SMTP service account from ethereal.email
  // Only needed if you don't have a real mail account for testing
  let testAccount =  nodemailer.createTestAccount();

  // create reusable transporter object using the default SMTP transport
  var transporter = await nodemailer.createTransport({
    name: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    auth: {
        user: "sarkerkumartapos@gmail.com",
        pass: "tapos42001"
    }
  });
  // send mail with defined transport object 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
  let info = await transporter.sendMail({
    from: '"Fred Foo 👻"flies-shelter@hgpmup2n.mailosaur.net',
    to: data.email,
    subject: "Activation link",
    html: "<b>Hello "+data.name+"</b><br><br>Activate your account using this link: <a href='https://eojp.herokuapp.com/confirm/"+data.confirmationToken+"/"+data.uid+"'>Activation Link</a>",
  },(err,res)=>{
      if (err) {
          console.log(err);
          return false;
      }else{
          return true;
      }
  });

  console.log("Message sent: %s", info);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  // Preview only available when sending through an Ethereal account
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
    }


    main().catch(console.error)
}

module.exports = mainfunction