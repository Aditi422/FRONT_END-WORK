var jwt = require('jsonwebtoken');

const generateJWTtoken = (id)=>{
    var stoken = '$2b$10$M5/.BBn0yWK91XqQcVpTY5FT54YTjcEyJMT9Rb1ldEPXnp/hhqYi0hzPO';
    return jwt.sign({ id },stoken , { expiresIn: '2h' });
}

module.exports = {
    generateJWTtoken,
}