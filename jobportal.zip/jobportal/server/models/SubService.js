const mongoose = require('mongoose')

const SubServiceSchema = mongoose.Schema({
    service:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Service',  
    },
    name:String,
    subserviceid:String,
    status:Boolean
})

const SubserviceModule = mongoose.model('SubService',SubServiceSchema)

module.exports = SubserviceModule