const mongoose = require('mongoose')


const WorkerSchema = mongoose.Schema({
    name:String,
    email:String,
    password:String,
    phone:String,
    image:String,
    contact:String,
    bio:String,
    location:String,
    rate:{type:Number,default:20},
    service:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Service'
    },
    subservice:[],
    DOB:{type:Date,default:null},
    gender:String,
    CNIC:String,
    experience:String,
    bankaccount:String,
    status:Number,
    addedby:String,
    totalJob:{type:Number,default:0},
    accountType:{type:String,default:'Worker'},
    review:[{
        user:String,
        stars:Number,
        comment:String,
        date:Date
    }],
    complains:[{
        user:String,
        userId:String,
        orderId:String,
        comaplainId:String,
        comment:String,
        date:Date
    }]
})

const WorkerModel = mongoose.model('Worker',WorkerSchema)

module.exports = WorkerModel