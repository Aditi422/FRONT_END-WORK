const mongoose = require('mongoose')

const categorySchema = mongoose.Schema({
    name:String,
    categoryid:String,
    status:Boolean
})

const categoryModule = mongoose.model('StaffCategory',categorySchema)

module.exports = categoryModule