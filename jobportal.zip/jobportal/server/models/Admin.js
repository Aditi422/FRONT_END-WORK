const mongoose = require('mongoose')

const AdminSchema = mongoose.Schema({
    name:String,
    email:{ type: String, required: true, unique: true },
    DOB:{type:Date,default:null},
    image:String,
    gender:String,
    password:String,
    CNIC:String,
    verifyToken:String,
    status:{type:Number,default:0},
    contact:String,
})

const AdminModel = mongoose.model('Admin',AdminSchema)

module.exports = AdminModel