const mongoose = require('mongoose')

const NotificationSchema = mongoose.Schema({
    from:String,
    fromid:String,
    to:String,
    toid:String,
    orderId:String,
    msg:String,
    view:{type:Boolean,default:false},
    msgType:String,
    extra:{type:Boolean,default:false}
})

const NotificationModel = mongoose.model('Notification',NotificationSchema)

module.exports = NotificationModel