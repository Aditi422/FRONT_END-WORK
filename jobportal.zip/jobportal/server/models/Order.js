const mongoose = require('mongoose')

const OrderSchema = mongoose.Schema({
    employer:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'User'
    },
    worker:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Worker'
    },
    totalamount:Number,
    rate:Number,
    date:{type:Date},
    shift:String,
    hours:{type:Number,default:1},
    details:String,
    orderNo:String,
    createdAt:Date,
    approvedBy:{type:String,default:'Admin'},
    status:{type:Number,default:1},
})

const OrderModel = mongoose.model('Order',OrderSchema)

module.exports = OrderModel