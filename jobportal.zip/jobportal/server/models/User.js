const mongoose = require('mongoose')

const UserSchema = mongoose.Schema({
    name:String,
    email:String,
    image:String,
    username:String,
    password:String,
    phone:String,
    Uid:String,
    gender:String,
    status:{
        type:Boolean,
        default:false
    },
    location:{
        type:String,
        default:null,
    },
    confirmationtoken:String,
})
const UserModel = mongoose.model('User',UserSchema)
module.exports = UserModel