const mongoose = require('mongoose')

const ServiceSchema = mongoose.Schema({
    name:String,
    serviceid:String,
    status:Boolean
})

const serviceModule = mongoose.model('Service',ServiceSchema)

module.exports = serviceModule