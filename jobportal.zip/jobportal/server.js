const express = require('express')
const session = require('express-session');
var bodyParser = require('body-parser')
var flash = require('connect-flash');
const AdminModel = require('./server/models/Admin')
require('dotenv').config()
const path = require('path'); 
const dbConfig = require('./database/dbconfig')
const app = express();

const port = process.env.PORT || 5000


app.use(session({ 
  secret:'secret',
  cookie: { maxAge: 86400000},
  saveUninitialized: true,
  resave: true
}));
//database connection
dbConfig.db()

app.use(function(req, res, next) {
  res.locals.user = req.session.user;
  res.locals.fuser = req.session.fuser;
  next();
});

// declaring the engine
app.set('view engine','ejs')
app.use(express.json())
app.use(express.urlencoded({extended:true})) //this middleware helps to get datas that are sent with the request andpare in req.body
app.use(flash());

// creating the static files
app.use(express.static(path.join(__dirname, '/public')))
app.use(express.static(path.join(__dirname, 'public/images')))

//displaying the url
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})


// creating the route group using prefix
const authAdminRoute = require('./routes/AdminRoute');
const FrontPageRoute = require('./routes/FrontPageRoute')

const { isValidObjectId } = require('mongoose');
// const fileRoute = require('./route/fileRoute')
app.use('/admin',authAdminRoute)
app.use('/',FrontPageRoute)